#include <iostream>
using namespace std;

int main() {
    // Declare Variables 
    int age, creditHours, feePerCreditHour;

    // Input from the user 
    cout << "Enter your age: ";
    cin >> age;

    cout << "Enter credit hours: ";
    cin >> creditHours;

    cout << "Enter fee per credit hour: ";
    cin >> feePerCreditHour;

    //  Calculate the semester fee and discounted fee 
    int totalFee = creditHours * feePerCreditHour;
    int discountedFee = totalFee - 2000;

    // Calculate birth year and the year student turns 25
    int birthYear = 2026 - age;
    int yearTurning25 = birthYear + 25;

    cout << "\nTotal fee: Rs. " << totalFee << endl;
    cout << "Fee after Rs. 2000 discount: Rs. " << discountedFee << endl;
    cout << "Year of birth: " << birthYear << endl;
    cout << "Year you will turn 25: " << yearTurning25 << endl;
    // Experiment 1:
    // Entering 19 15 8000 on one line works.
    // Entering values on separate lines also works.
    // Entering values separated by tabs also works.
    // Reason: cin >> reads and skips whitespace, including
    // spaces, tabs, and newlines.

    // Experiment 2:
    // If age is entered as 19.8, cin stores 19 in age.
    // The decimal point and remaining characters stay in
    // the input stream. The next integer input may fail
    // because the remaining input is not a valid integer.
    // Therefore, the program may not read later values correctly.
    return 0;
}