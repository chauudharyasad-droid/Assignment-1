#include <iostream>
using namespace std;
int main()
{
	int price, quantity, total, tax, grandtotal;
	cout << "Enter the price: ";
	cin >> price;

	cout << "Enter the quantity:";
	cin >> quantity;

	total = price * quantity;


	tax = total * 5 / 100;

	grandtotal = total + tax;

	cout << "Total: " << total << endl;
	cout << "Tax: " << tax << endl;
	cout << "Grandtotal: " << grandtotal << endl;

	return 0;

}