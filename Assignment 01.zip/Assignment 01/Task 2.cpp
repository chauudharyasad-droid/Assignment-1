#include <iostream>
using namespace std;
int main()
{
	// This section contains four syntax error. 
	// Missing semicolon after the first statement. 
	cout << "Orientation Day" << endl;
	// Missing << before 450.
	cout << "Total students: " << 450 << endl;
	// No correction is needed.
	cout << "Seats left: " << 500 - 450 << endl;
	// Missing ' quote after the day.
	cout << "Have a nice day" << endl;

	// Second part: Semantic error 

		//The original line is printed because the division operation takes place before the addition.
	cout << "Average: " << 60 + 70 + 80 / 3 << endl;
	// Corrected calculation using brackets.
	cout << "Average: " << (60 + 70 + 80) / 3 << endl;

	return 0;
}