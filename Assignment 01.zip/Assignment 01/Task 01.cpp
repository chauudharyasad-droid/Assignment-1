// Name: Asad Ali
// Roll no: 0110
#include <iostream>
using namespace std;
int main()
{

	// Print Hello World on the first line
	cout << "Hello World" << endl;
	// Print University information using one cout statement
	cout << "University of Central Punjab\nFaculty of Information Technology\nOrientation Day 2026\n";
	// Print Welcome using endl
	cout << "Welcome" << endl;
	// Print numbers and arithmetic expressions
	cout << 2026 << endl;
	cout << 45 << endl;
	cout << 45 * 3 << endl;
	cout << 1000 + 500 - 250 << endl;
	// Print total fee using an arithmetic expression 
	cout << "Total fee: " << 45000 + 9000 << endl;

	// Observation: Missing semicolon 
	// error: expected';' before
	"return";
		// Correction: Adding the missing semicolon 
		int number = 10;

	// Observation: Incorrect capitalization of cout 
	// error: 'Cout' was not declared in this scope 

	// Correction: using lowercase 'cout' because C++ is case-sensitive
	cout << "Errors corrected Successfully!" << endl;

	return 0;

}