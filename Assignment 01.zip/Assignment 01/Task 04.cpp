#include <iostream>
using namespace std;
int main()
{
	// Dcelare and initialize variables 
	int rollNo = 1045;
	int semester = 1;
	char section = 'B';
	float cgpa = 3.5;
	int totalfee = 45000;
	int feepaid = 20000;

	// Display All values 
	cout << "Roll NUmber: " << rollNo << endl;
	cout << "Semester: " << semester << endl;
	cout << "Section: " << section << endl;
	cout << "CGPA: " << cgpa << endl;
	cout << "Toatl fee: " << totalfee << endl;
	cout << "feepaid: " << feepaid << endl;

	// Move to next semester and add second installment
	semester = semester + 1;
	feepaid = feepaid + 5000;

	// calculate the remaining fee and percentage of the fee paid
	int remainingFee = totalfee - feepaid;
	int percentagepaid = feepaid * 100 / totalfee;
	// Again display all values
	cout << "Semester: " << semester << endl;
	cout << "Fee paid: " << feepaid << endl;
	cout << "Remaining fee: " << remainingFee << endl;
	cout << "Percentage paid: " << percentagepaid << endl;

	// Valid and invalid identifiers
	// 2ndYear     : Invalid 
	// student_name: Valid
	// total marks : Invalid 
	// _fee        : Valid
	// Roll No     : Invalid 
	// marks2      : Valid

	// Observation:
	// Declaring int x; without initialization and printing it
	// It is unsafe 
	return 0;

}