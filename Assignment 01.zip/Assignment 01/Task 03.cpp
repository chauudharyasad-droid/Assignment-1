#include <iostream>
using namespace std;
int main()
{
	cout << "Expression 1: " << 10 + 5 * 2 << endl; // output : 20
	cout << "Expression 2: " << (10 + 5) * 2 << endl; // output : 30
	// Operators is evaluated left to right
	cout << "Expression 3: " << 20 - 5 - 3 << endl; // output : 12
	cout << "Exoression 4: " << 100 / 7 << endl; // output : 14
	cout << "Expression 5: " << 100 % 7 << endl; // ouput : 2
	// Expression 6: Original expression
	cout << "Expression 6: " << 2 * 3 + 8 / 4 - 2 << endl; // output : 6

	// Expression 6: Adding the brackets to produce 8
	cout << "Expression 6: " << 2 * (3 + 8 / 4) - 2 << endl;
	return 0;


}